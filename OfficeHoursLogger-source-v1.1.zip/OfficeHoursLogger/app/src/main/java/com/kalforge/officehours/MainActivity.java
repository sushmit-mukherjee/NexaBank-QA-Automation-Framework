package com.kalforge.officehours;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Bundle;
import android.os.Handler;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class MainActivity extends Activity {
    private static final String PREFS = "office_hours_prefs";
    private static final String KEY_SESSIONS = "sessions";
    private static final String KEY_ACTIVE_START = "active_start";
    private static final String KEY_TARGET_MS = "target_ms";
    private static final long DEFAULT_TARGET_MS = 8L * 60L * 60L * 1000L;
    private static final long MAX_TARGET_MS = 24L * 60L * 60L * 1000L;
    private static final String DATE_TIME_PATTERN = "yyyy-MM-dd HH:mm:ss";

    private SharedPreferences prefs;
    private final Handler handler = new Handler();
    private TextView statusView;
    private TextView currentTimerView;
    private TextView targetView;
    private TextView todayTotalView;
    private TextView remainingView;
    private TextView overtimeView;
    private TextView shortfallView;
    private TextView projectedView;
    private TextView historyView;
    private Button toggleButton;
    private Button undoButton;

    private final Runnable ticker = new Runnable() {
        @Override public void run() {
            refresh();
            handler.postDelayed(this, 1000);
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        prefs = getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        buildUi();
        refresh();
    }

    @Override
    protected void onResume() {
        super.onResume();
        handler.removeCallbacks(ticker);
        handler.post(ticker);
    }

    @Override
    protected void onPause() {
        super.onPause();
        handler.removeCallbacks(ticker);
    }

    private void buildUi() {
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setBackgroundColor(Color.rgb(246, 247, 249));

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(20), dp(28), dp(20), dp(28));
        scroll.addView(root);

        TextView title = text("Office Hours", 30, true);
        root.addView(title);

        TextView subtitle = text("One-tap office time tracker", 15, false);
        subtitle.setTextColor(Color.DKGRAY);
        subtitle.setPadding(0, dp(4), 0, dp(26));
        root.addView(subtitle);

        statusView = text("", 16, true);
        statusView.setGravity(Gravity.CENTER);
        root.addView(statusView, fullWidth(dp(44)));

        currentTimerView = text("00:00:00", 44, true);
        currentTimerView.setGravity(Gravity.CENTER);
        currentTimerView.setTypeface(Typeface.MONOSPACE, Typeface.BOLD);
        currentTimerView.setPadding(0, dp(18), 0, dp(18));
        root.addView(currentTimerView);

        toggleButton = new Button(this);
        toggleButton.setTextSize(19);
        toggleButton.setAllCaps(false);
        toggleButton.setMinHeight(dp(60));
        toggleButton.setOnClickListener(v -> toggleSession());
        root.addView(toggleButton, fullWidth(dp(64)));

        addSpacer(root, 24);
        addSectionLabel(root, "TODAY");

        targetView = valueRow(root, "Target", "08:00:00");
        todayTotalView = valueRow(root, "Logged", "00:00:00");
        remainingView = valueRow(root, "Remaining", "08:00:00");
        overtimeView = valueRow(root, "Overtime", "00:00:00");
        shortfallView = valueRow(root, "Shortfall", "08:00:00");
        projectedView = valueRow(root, "Estimated checkout", "—");

        Button targetButton = new Button(this);
        targetButton.setText("Set daily target");
        targetButton.setAllCaps(false);
        targetButton.setOnClickListener(v -> showTargetDialog());
        root.addView(targetButton, fullWidth(dp(52)));

        Button editButton = new Button(this);
        editButton.setText("Edit / add time logs");
        editButton.setAllCaps(false);
        editButton.setOnClickListener(v -> showLogManager());
        root.addView(editButton, fullWidth(dp(52)));

        addSpacer(root, 26);
        addSectionLabel(root, "RECENT DAYS");
        historyView = text("", 15, false);
        historyView.setTypeface(Typeface.MONOSPACE);
        historyView.setLineSpacing(dp(3), 1f);
        historyView.setPadding(0, dp(8), 0, dp(12));
        root.addView(historyView);

        undoButton = new Button(this);
        undoButton.setText("Undo last completed session");
        undoButton.setAllCaps(false);
        undoButton.setOnClickListener(v -> undoLastSession());
        root.addView(undoButton, fullWidth(dp(52)));

        Button clearButton = new Button(this);
        clearButton.setText("Clear all data");
        clearButton.setAllCaps(false);
        clearButton.setOnClickListener(v -> confirmClear());
        root.addView(clearButton, fullWidth(dp(52)));

        TextView note = text("All logs and settings stay on this phone. No account, internet, or permissions required.", 13, false);
        note.setTextColor(Color.GRAY);
        note.setGravity(Gravity.CENTER);
        note.setPadding(dp(8), dp(18), dp(8), 0);
        root.addView(note);

        setContentView(scroll);
    }

    private TextView valueRow(LinearLayout root, String label, String initial) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(0, dp(6), 0, dp(6));

        TextView l = text(label, 16, false);
        row.addView(l, new LinearLayout.LayoutParams(0, dp(40), 1f));

        TextView v = text(initial, 16, true);
        v.setGravity(Gravity.END | Gravity.CENTER_VERTICAL);
        v.setTypeface(Typeface.MONOSPACE, Typeface.BOLD);
        row.addView(v, new LinearLayout.LayoutParams(0, dp(40), 1.25f));
        root.addView(row);
        return v;
    }

    private void addSectionLabel(LinearLayout root, String s) {
        TextView label = text(s, 13, true);
        label.setTextColor(Color.GRAY);
        root.addView(label);
    }

    private void addSpacer(LinearLayout root, int dps) {
        View v = new View(this);
        root.addView(v, fullWidth(dp(dps)));
    }

    private TextView text(String s, int sp, boolean bold) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(sp);
        t.setTextColor(Color.rgb(30, 32, 36));
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return t;
    }

    private LinearLayout.LayoutParams fullWidth(int height) {
        return new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, height);
    }

    private int dp(int v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }

    private long activeStart() {
        return prefs.getLong(KEY_ACTIVE_START, 0L);
    }

    private long targetMs() {
        return prefs.getLong(KEY_TARGET_MS, DEFAULT_TARGET_MS);
    }

    private void toggleSession() {
        long active = activeStart();
        long now = System.currentTimeMillis();
        if (active == 0L) {
            prefs.edit().putLong(KEY_ACTIVE_START, now).apply();
            Toast.makeText(this, "Checked in", Toast.LENGTH_SHORT).show();
        } else {
            if (now <= active) {
                Toast.makeText(this, "Phone time changed. Session was not saved.", Toast.LENGTH_LONG).show();
                return;
            }
            saveSession(active, now);
            prefs.edit().remove(KEY_ACTIVE_START).apply();
            Toast.makeText(this, "Checked out", Toast.LENGTH_SHORT).show();
        }
        refresh();
    }

    private void saveSession(long start, long end) {
        JSONArray arr = loadSessions();
        JSONObject o = new JSONObject();
        try {
            o.put("start", start);
            o.put("end", end);
            arr.put(o);
            prefs.edit().putString(KEY_SESSIONS, arr.toString()).apply();
        } catch (JSONException ignored) { }
    }

    private JSONArray loadSessions() {
        String raw = prefs.getString(KEY_SESSIONS, "[]");
        try { return new JSONArray(raw); }
        catch (JSONException e) { return new JSONArray(); }
    }

    private List<Session> sessions() {
        JSONArray arr = loadSessions();
        List<Session> out = new ArrayList<>();
        for (int i = 0; i < arr.length(); i++) {
            try {
                JSONObject o = arr.getJSONObject(i);
                long s = o.getLong("start");
                long e = o.getLong("end");
                if (e > s) out.add(new Session(s, e));
            } catch (JSONException ignored) { }
        }
        return out;
    }

    private void refresh() {
        long now = System.currentTimeMillis();
        long active = activeStart();
        boolean running = active > 0L;
        long target = targetMs();

        statusView.setText(running ? "●  CHECKED IN" : "○  CHECKED OUT");
        statusView.setTextColor(running ? Color.rgb(22, 120, 65) : Color.rgb(95, 99, 104));
        toggleButton.setText(running ? "Check Out" : "Check In");

        long current = running ? Math.max(0L, now - active) : 0L;
        currentTimerView.setText(formatDuration(current));

        long today = totalForDay(now, true);
        long remaining = Math.max(0L, target - today);
        long overtime = Math.max(0L, today - target);
        long shortfall = Math.max(0L, target - today);

        targetView.setText(formatDuration(target));
        todayTotalView.setText(formatDuration(today));
        remainingView.setText(remaining == 0L ? "DONE" : formatDuration(remaining));
        overtimeView.setText(formatDuration(overtime));
        shortfallView.setText(formatDuration(shortfall));

        if (running && remaining > 0L) {
            projectedView.setText(new SimpleDateFormat("h:mm:ss a", Locale.getDefault()).format(new Date(now + remaining)));
        } else if (today >= target) {
            projectedView.setText("Target reached");
        } else {
            projectedView.setText("—");
        }

        historyView.setText(buildHistory(now));
        undoButton.setEnabled(loadSessions().length() > 0);
    }

    private long totalForDay(long referenceMs, boolean includeActive) {
        Calendar c = Calendar.getInstance();
        c.setTimeInMillis(referenceMs);
        c.set(Calendar.HOUR_OF_DAY, 0);
        c.set(Calendar.MINUTE, 0);
        c.set(Calendar.SECOND, 0);
        c.set(Calendar.MILLISECOND, 0);
        long dayStart = c.getTimeInMillis();
        c.add(Calendar.DAY_OF_MONTH, 1);
        long dayEnd = c.getTimeInMillis();

        long total = 0L;
        for (Session s : sessions()) total += overlap(s.start, s.end, dayStart, dayEnd);

        if (includeActive) {
            long active = activeStart();
            if (active > 0L) total += overlap(active, System.currentTimeMillis(), dayStart, dayEnd);
        }
        return total;
    }

    private long overlap(long start, long end, long rangeStart, long rangeEnd) {
        long s = Math.max(start, rangeStart);
        long e = Math.min(end, rangeEnd);
        return Math.max(0L, e - s);
    }

    private String buildHistory(long now) {
        StringBuilder sb = new StringBuilder();
        Calendar c = Calendar.getInstance();
        c.setTimeInMillis(now);
        SimpleDateFormat df = new SimpleDateFormat("EEE, dd MMM", Locale.getDefault());
        long target = targetMs();
        for (int i = 0; i < 7; i++) {
            long ref = c.getTimeInMillis();
            long total = totalForDay(ref, i == 0);
            long delta = total - target;
            String variance = delta >= 0 ? "+" + formatDuration(delta) : "-" + formatDuration(-delta);
            sb.append(df.format(new Date(ref)))
                    .append("  ")
                    .append(formatDuration(total))
                    .append("  ")
                    .append(variance);
            if (i < 6) sb.append("\n");
            c.add(Calendar.DAY_OF_MONTH, -1);
        }
        return sb.toString();
    }

    private String formatDuration(long ms) {
        long seconds = Math.max(0L, ms / 1000L);
        long h = seconds / 3600L;
        long m = (seconds % 3600L) / 60L;
        long s = seconds % 60L;
        return String.format(Locale.US, "%02d:%02d:%02d", h, m, s);
    }

    private void showTargetDialog() {
        long current = targetMs();
        long totalMinutes = current / 60000L;

        LinearLayout box = dialogBox();
        EditText hours = numberInput("Hours", String.valueOf(totalMinutes / 60L));
        EditText minutes = numberInput("Minutes", String.valueOf(totalMinutes % 60L));
        box.addView(hours);
        box.addView(minutes);

        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle("Daily target")
                .setMessage("Set the office-hours target used for remaining time, overtime and shortfall.")
                .setView(box)
                .setNegativeButton("Cancel", null)
                .setPositiveButton("Save", null)
                .create();

        dialog.setOnShowListener(d -> dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v -> {
            try {
                long h = Long.parseLong(hours.getText().toString().trim());
                long m = Long.parseLong(minutes.getText().toString().trim());
                long value = (h * 60L + m) * 60000L;
                if (h < 0 || m < 0 || m > 59 || value <= 0L || value > MAX_TARGET_MS) {
                    throw new NumberFormatException();
                }
                prefs.edit().putLong(KEY_TARGET_MS, value).apply();
                Toast.makeText(this, "Daily target updated", Toast.LENGTH_SHORT).show();
                dialog.dismiss();
                refresh();
            } catch (NumberFormatException ex) {
                Toast.makeText(this, "Enter a target between 00:01 and 24:00", Toast.LENGTH_LONG).show();
            }
        }));
        dialog.show();
    }

    private EditText numberInput(String hint, String value) {
        EditText input = new EditText(this);
        input.setHint(hint);
        input.setText(value);
        input.setSelectAllOnFocus(true);
        input.setInputType(InputType.TYPE_CLASS_NUMBER);
        return input;
    }

    private LinearLayout dialogBox() {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        int p = dp(20);
        box.setPadding(p, dp(4), p, 0);
        return box;
    }

    private void showLogManager() {
        List<String> choices = new ArrayList<>();
        if (activeStart() > 0L) choices.add("Correct current check-in");
        if (loadSessions().length() > 0) choices.add("Edit completed session");
        choices.add("Add completed session");

        new AlertDialog.Builder(this)
                .setTitle("Time logs")
                .setItems(choices.toArray(new String[0]), (d, which) -> {
                    String choice = choices.get(which);
                    if (choice.startsWith("Correct")) editActiveStart();
                    else if (choice.startsWith("Edit")) chooseCompletedSession();
                    else addManualSession();
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    private void editActiveStart() {
        long active = activeStart();
        if (active <= 0L) return;
        LinearLayout box = dialogBox();
        EditText start = dateTimeInput("Check-in", active);
        box.addView(start);

        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle("Correct current check-in")
                .setMessage("Format: " + DATE_TIME_PATTERN)
                .setView(box)
                .setNegativeButton("Cancel", null)
                .setPositiveButton("Save", null)
                .create();

        dialog.setOnShowListener(d -> dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v -> {
            Long parsed = parseDateTime(start.getText().toString());
            long now = System.currentTimeMillis();
            if (parsed == null || parsed <= 0L || parsed >= now) {
                Toast.makeText(this, "Check-in must be a valid time before now", Toast.LENGTH_LONG).show();
                return;
            }
            prefs.edit().putLong(KEY_ACTIVE_START, parsed).apply();
            Toast.makeText(this, "Current check-in corrected", Toast.LENGTH_SHORT).show();
            dialog.dismiss();
            refresh();
        }));
        dialog.show();
    }

    private void chooseCompletedSession() {
        JSONArray arr = loadSessions();
        if (arr.length() == 0) return;
        List<String> labels = new ArrayList<>();
        List<Integer> indexes = new ArrayList<>();
        SimpleDateFormat f = new SimpleDateFormat("dd MMM  HH:mm:ss", Locale.getDefault());

        for (int i = arr.length() - 1; i >= 0; i--) {
            try {
                JSONObject o = arr.getJSONObject(i);
                long s = o.getLong("start");
                long e = o.getLong("end");
                labels.add(f.format(new Date(s)) + " → " + f.format(new Date(e)) + "  (" + formatDuration(e - s) + ")");
                indexes.add(i);
                if (labels.size() >= 30) break;
            } catch (JSONException ignored) { }
        }

        new AlertDialog.Builder(this)
                .setTitle("Choose session to edit")
                .setItems(labels.toArray(new String[0]), (d, which) -> editCompletedSession(indexes.get(which)))
                .setNegativeButton("Cancel", null)
                .show();
    }

    private void editCompletedSession(int index) {
        JSONArray arr = loadSessions();
        try {
            JSONObject o = arr.getJSONObject(index);
            showSessionEditor("Edit completed session", o.getLong("start"), o.getLong("end"), (start, end) -> {
                try {
                    JSONObject changed = new JSONObject();
                    changed.put("start", start);
                    changed.put("end", end);
                    arr.put(index, changed);
                    prefs.edit().putString(KEY_SESSIONS, arr.toString()).apply();
                    Toast.makeText(this, "Session corrected", Toast.LENGTH_SHORT).show();
                    refresh();
                } catch (JSONException ignored) { }
            }, () -> {
                JSONArray next = new JSONArray();
                for (int i = 0; i < arr.length(); i++) {
                    if (i == index) continue;
                    try { next.put(arr.get(i)); } catch (JSONException ignored) { }
                }
                prefs.edit().putString(KEY_SESSIONS, next.toString()).apply();
                Toast.makeText(this, "Session deleted", Toast.LENGTH_SHORT).show();
                refresh();
            });
        } catch (JSONException ignored) { }
    }

    private void addManualSession() {
        long now = System.currentTimeMillis();
        long oneHourAgo = now - 60L * 60L * 1000L;
        showSessionEditor("Add completed session", oneHourAgo, now, (start, end) -> {
            saveSession(start, end);
            Toast.makeText(this, "Manual session added", Toast.LENGTH_SHORT).show();
            refresh();
        }, null);
    }

    private interface SessionSave { void save(long start, long end); }
    private interface DeleteAction { void delete(); }

    private void showSessionEditor(String title, long startMs, long endMs, SessionSave saver, DeleteAction deleter) {
        LinearLayout box = dialogBox();
        TextView startLabel = text("Start", 13, true);
        startLabel.setTextColor(Color.GRAY);
        EditText start = dateTimeInput("Start", startMs);
        TextView endLabel = text("End", 13, true);
        endLabel.setTextColor(Color.GRAY);
        EditText end = dateTimeInput("End", endMs);
        box.addView(startLabel);
        box.addView(start);
        box.addView(endLabel);
        box.addView(end);

        AlertDialog.Builder builder = new AlertDialog.Builder(this)
                .setTitle(title)
                .setMessage("Enter exact local date/time as " + DATE_TIME_PATTERN)
                .setView(box)
                .setNegativeButton("Cancel", null)
                .setPositiveButton("Save", null);
        if (deleter != null) builder.setNeutralButton("Delete", null);
        AlertDialog dialog = builder.create();

        dialog.setOnShowListener(d -> {
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v -> {
                Long s = parseDateTime(start.getText().toString());
                Long e = parseDateTime(end.getText().toString());
                if (s == null || e == null || e <= s) {
                    Toast.makeText(this, "Use valid times and make End later than Start", Toast.LENGTH_LONG).show();
                    return;
                }
                saver.save(s, e);
                dialog.dismiss();
            });
            if (deleter != null) {
                dialog.getButton(AlertDialog.BUTTON_NEUTRAL).setOnClickListener(v -> new AlertDialog.Builder(this)
                        .setTitle("Delete this session?")
                        .setNegativeButton("Cancel", null)
                        .setPositiveButton("Delete", (confirm, w) -> {
                            deleter.delete();
                            dialog.dismiss();
                        }).show());
            }
        });
        dialog.show();
    }

    private EditText dateTimeInput(String hint, long value) {
        EditText input = new EditText(this);
        input.setHint(hint);
        input.setSingleLine(true);
        input.setText(formatDateTime(value));
        input.setSelectAllOnFocus(true);
        input.setInputType(InputType.TYPE_CLASS_DATETIME | InputType.TYPE_DATETIME_VARIATION_NORMAL);
        return input;
    }

    private String formatDateTime(long value) {
        return new SimpleDateFormat(DATE_TIME_PATTERN, Locale.getDefault()).format(new Date(value));
    }

    private Long parseDateTime(String value) {
        SimpleDateFormat f = new SimpleDateFormat(DATE_TIME_PATTERN, Locale.getDefault());
        f.setLenient(false);
        try {
            Date d = f.parse(value.trim());
            return d == null ? null : d.getTime();
        } catch (ParseException e) {
            return null;
        }
    }

    private void undoLastSession() {
        JSONArray arr = loadSessions();
        if (arr.length() == 0) return;
        JSONArray next = new JSONArray();
        for (int i = 0; i < arr.length() - 1; i++) {
            try { next.put(arr.get(i)); } catch (JSONException ignored) { }
        }
        prefs.edit().putString(KEY_SESSIONS, next.toString()).apply();
        Toast.makeText(this, "Last session removed", Toast.LENGTH_SHORT).show();
        refresh();
    }

    private void confirmClear() {
        new AlertDialog.Builder(this)
                .setTitle("Clear all office-hour data?")
                .setMessage("This permanently removes all completed sessions, the active check-in, and your custom target.")
                .setNegativeButton("Cancel", null)
                .setPositiveButton("Clear", (d, w) -> {
                    prefs.edit().clear().apply();
                    Toast.makeText(this, "All data cleared", Toast.LENGTH_SHORT).show();
                    refresh();
                })
                .show();
    }

    private static final class Session {
        final long start;
        final long end;
        Session(long start, long end) { this.start = start; this.end = end; }
    }
}
