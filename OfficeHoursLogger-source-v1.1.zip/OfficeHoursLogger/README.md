# Office Hours Logger

A small offline Android app for exact office-hours logging.

## Features
- One-tap Check In / Check Out
- Live HH:MM:SS timer
- Persistent active session across app restarts
- Custom daily target (hours + minutes)
- Exact remaining time and estimated checkout time
- Live overtime and shortfall
- Seven-day history with signed variance against the current target
- Manual correction of the active check-in
- Edit or delete completed sessions
- Add missed/manual completed sessions
- Undo the most recent completed session
- Local-only storage; no internet/account/permissions required

## Build
Open this folder in Android Studio and build the `app` module, or run the Gradle wrapper when available.

Application ID: `com.kalforge.officehours`
Version: 1.1 (2)
Minimum Android: 8.0 / API 26
Target/compile SDK: API 35
